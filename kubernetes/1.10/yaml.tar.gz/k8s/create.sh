kubectl create secret docker-registry regcred --docker-server=http://registry.dev.chelizitech.com --docker-username=saas --docker-password=Abcd1234 --docker-email=r@y.cn



kubectl get secrets --all-namespaces
kubectl describe secrets kube-admin-token-fbbfv -n kube-system
